<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHITHRA AGENCY</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="icon" type="icon" href="invoice.jpg">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .container_1 {
            max-width: 900px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 0;
                box-shadow: none;
            }
        }
        nav{
            text-align: center;

        }
         h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            text-align: center;
        }
        th {
            background-color: #343a40;
            color: #ffffff;
            font-weight: bold;
        }
        .customer-name {
            cursor: pointer;
            font-weight: bold;
            color: #007bff;
        }
        .customer-details {
            display: none;
        }
        .print-btn {
            padding: 8px 16px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .print-btn:hover {
            background-color: #0056b3;
        }
        @media only screen and (max-width: 768px) {
            .container {
                padding: 20px;
                border-radius: 0;
                box-shadow: none;
            }
        }

    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container_1">
            <a class="navbar-brand" href="#">Invoice System</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php" style="color:black;text-align: center;margin-right: 150px;"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="invoice.php" style="color:black;text-align: center;margin-right:150px;"><i class="fas fa-file-invoice-dollar"></i> Invoice</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales.php" style="color:black;text-align: center;margin-right: 150px;"><i class="fas fa-chart-line"></i> Sales</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
<div class="container">

<h2>Invoice Report</h2>

<table>
    <tr>
        <th class="mobile-view">ID</th>
        <th class="mobile-view">Customer Name</th>
        <th class="mobile-view">Cement Name</th>
        <th class="mobile-view">Amount</th>
        <th class="mobile-view">Date</th>
    </tr>
    <?php
    require_once "connect.php"; // Include your database connection script

    // SQL query to fetch transaction details
    $sql = "SELECT * FROM invoices";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td class='mobile-view'>".$row['id']."</td>";
            echo "<td class='customer-name' onclick='showTransactionDetails(this)'>".$row['customer_name']."</td>";
            echo "<td class='mobile-view'>".$row['cement_name']."</td>";
            echo "<td class='mobile-view'>".$row['grant_total']."</td>";
            echo "<td class='mobile-view'>".$row['date']."</td>";
            echo "</tr>";
            echo "<tr class='customer-details' style='display: none;'>";
            echo "<td colspan='5' class='vertical-details'>";
            echo "<table>";
            echo "<tr><td>ID:</td><td>".$row['id']."</td></tr>";
            echo "<tr><td>Customer Name:</td><td>".$row['customer_name']."</td></tr>";
            echo "<tr><td>Customer Address:</td><td>".$row['customer_address']."</td></tr>";
            echo "<tr><td>Date:</td><td>".$row['date']."</td></tr>";
            echo "<tr><td>Cement Name:</td><td>".$row['cement_name']."</td></tr>";
            echo "<tr><td>HSN Code:</td><td>".$row['hsn_code']."</td></tr>";
            echo "<tr><td>Quantity:</td><td>".$row['quantity']."</td></tr>";
            echo "<tr><td>Price:</td><td>".$row['price']."</td></tr>";
            echo "<tr><td>SGST:</td><td>".$row['sgst']."</td></tr>";
            echo "<tr><td>CGST:</td><td>".$row['cgst']."</td></tr>";
            echo "<tr><td>Grant Total:</td><td>".$row['grant_total']."</td></tr>";
            echo "<tr><td>Transaction Date & Time:</td><td>".$row['transaction_d_t']."</td></tr>";
            echo "<tr><td colspan='2'> <a href='print_invoice.php?id=" . $row["id"] . "' class='btn btn-primary' target='_blank'>Print</a></td></tr>";

            echo "</table>";
            echo "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No transactions found</td></tr>";
    }
    // Close database connection
    $conn->close();
    ?>
</table>

</div>

<script>
    function showTransactionDetails(element) {
        var row = element.parentNode;
        var nextRow = row.nextElementSibling;
        if (nextRow.classList.contains('customer-details')) {
            if (nextRow.style.display === 'table-row') {
                nextRow.style.display = 'none';
            } else {
                nextRow.style.display = 'table-row';
            }
        }
    }

    function printTransactionDetails(id) {
        // Implement printing logic here for specific transaction details
        // For demonstration purpose, let's just alert the ID
        alert("Printing details for Transaction ID: " + id);
    }
</script>

</body>
</html>
