<?php
require_once "connect.php"; // Include your database connection script

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from POST request
    $customerName = $_POST['customerName'];
    $customerAddress = $_POST['customerAddress'];
    $date = $_POST['date'];
    $cementName = $_POST['cementName'];
    $hsnCode = $_POST['hsnCode'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $sgst = $_POST['sgst'];
    $cgst = $_POST['cgst'];
    $trans_D_T = $_POST['trans_D_T'];
    $grantTotal = $_POST['grantTotal'];

    // SQL query to insert data into the database
    $sql = "INSERT INTO invoices (customer_name, customer_address, date, cement_name, hsn_code, quantity, price, sgst, cgst, grant_total, transaction_d_t) 
            VALUES ('$customerName', '$customerAddress', '$date', '$cementName', '$hsnCode', '$quantity', '$price', '$sgst', '$cgst', '$grantTotal', '$trans_D_T')";

    // Execute SQL query
    if ($conn->query($sql) === TRUE) {
        // Generate PDF
        require('fpdf.php'); // Include FPDF library file
        
        // Function to generate PDF
        // Create new instance of FPDF class
        $pdf = new FPDF();
        $pdf->AddPage();
        
        // Add company logo and details
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Chithra Agency', 0, 1, 'C');
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 10, 'Address: 1/487, No: 3, Komarapalayam, Mallur, SALEM - 636 203. TAMIL NADU.', 0, 1, 'C');
        $pdf->Cell(0, 10, 'Phone: +91 95973 01136', 0, 1, 'C');
        $pdf->Cell(0, 10, 'GSTIN: 33AYUPC4227B1ZS', 0, 1, 'C');
        $pdf->Ln(10); // Add some space
        
        // Add invoice details
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 10, 'Invoice Details', 0, 1, 'C');
        
        // Manually specify each field and its text
        $fields = array(
            "ID" => $conn->insert_id,
            "Customer Name" => $customerName,
            "Customer Address" => $customerAddress,
            "Date" => $date,
            "Cement Name" => $cementName,
            "HSN Code" => $hsnCode,
            "Quantity" => $quantity,
            "Price" => $price,
            "SGST" => $sgst,
            "CGST" => $cgst,
            "Grant Total" => $grantTotal,
            "Transaction Date & Time" => $trans_D_T
        );

        // Create a table for invoice details
        $pdf->SetFont('Arial', 'B', 12);
        foreach ($fields as $label => $value) {
            // Convert label to uppercase
            $label_upper = strtoupper($label);
            $pdf->Cell(80, 10, $label_upper, 1);
            $pdf->Cell(0, 10, $value, 1);
            $pdf->Ln();
        }
        
        // Output PDF with filename including current date and time
        $filename = "Invoice_" . date('Y-m-d_H-i-s') . ".pdf";
        $pdf->Output($filename, 'D');
    } else {
        // Handle SQL execution error
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close database connection
$conn->close();
?>
