<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHITHRA AGENCY</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="icon" type="icon" href="invoice.jpg">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
         body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container { max-width: 75%; margin: 50px auto;
         background-color: #fff; padding: 30px; border-radius: 10px;
         box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); overflow-x: auto; /*
         Add horizontal scroll if needed */ }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        @media (max-width: 768px) {
            .container {
                padding: 20px;
                border-radius: 0;
                box-shadow: none;
            }
            table {
                width: 100%;
            }
        }
        nav {
            text-align: center;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            text-align: center;
        }
        th {
            background-color: #343a40;
            color: #ffffff;
            font-weight: bold;
        }
        .customer-name {
            cursor: pointer;
            font-weight: bold;
            color: #007bff;
        }
        .customer-details {
            display: none;
        }
        .print-btn {
            padding: 8px 16px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .print-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
       <div class="container">
            <a class="navbar-brand" href="#">Invoice System</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php" style="color:black;text-align: center;margin-right: 150px;"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="invoice.php" style="color:black;text-align: center;margin-right:150px;"><i class="fas fa-file-invoice-dollar"></i> Invoice</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales.php" style="color:black;text-align: center;margin-right: 150px;"><i class="fas fa-chart-line"></i> Sales</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <?php
        require_once "connect.php";

        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["date"])) {
            // Get selected date
            $date = $_GET["date"];

            // Fetch sales data based on selected date
            $sql = "SELECT * FROM invoices WHERE date = '$date'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<h2>Sales Report</h2>";
                echo "<table class='table'>";
                echo "<tr><th>ID</th><th>Customer Name</th><th>Customer Address</th><th>Date</th><th>Cement Name</th><th>HSN Code</th><th>Quantity</th><th>Price</th><th>SGST</th><th>CGST</th><th>Grant Total</th><th>Transaction Date & Time</th></tr>";

                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['id']."</td>";
                    echo "<td>".$row['customer_name']."</td>";
                    echo "<td>".$row['customer_address']."</td>";
                    echo "<td>".$row['date']."</td>";
                    echo "<td>".$row['cement_name']."</td>";
                    echo "<td>".$row['hsn_code']."</td>";
                    echo "<td>".$row['quantity']."</td>";
                    echo "<td>".$row['price']."</td>";
                    echo "<td>".$row['sgst']."</td>";
                    echo "<td>".$row['cgst']."</td>";
                    echo "<td>".$row['grant_total']."</td>";
                    echo "<td>".$row['transaction_d_t']."</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No sales found for the selected date.</p>";
            }
        }
        ?>
        <h2>Select Report Criteria</h2>
        <form method="GET" action="">
            <div class="form-group">
                <label for="date">Choose Date:</label>
                <input type="date" id="date" name="date" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Generate Report</button>
        </form>
    </div>

    <!-- Your JavaScript code here -->

</body>
</html>
