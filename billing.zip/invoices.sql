-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2024 at 10:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_address` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `cement_name` varchar(255) DEFAULT NULL,
  `hsn_code` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `sgst` decimal(5,2) DEFAULT NULL,
  `cgst` decimal(5,2) DEFAULT NULL,
  `grant_total` decimal(10,2) DEFAULT NULL,
  `transaction_d_t` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `customer_name`, `customer_address`, `date`, `cement_name`, `hsn_code`, `quantity`, `price`, `sgst`, `cgst`, `grant_total`, `transaction_d_t`) VALUES
(1, 'k7', 'mallur', '2024-05-11', 'Ultra Tech', 'hsaihfibaekf', 2, 25.00, 1.00, 1.00, 52.00, '2024-05-11 19:56:36'),
(2, 'Dummy', 'Salem', '2024-05-11', 'Dalmia Cement', 'HISKBDN', 2, 70.00, 56.00, 55.00, 0.00, '2024-05-11 21:30:20'),
(3, 'Dumy', 'Salem', '2024-05-11', 'Dalmia Cement', 'HDJND', 1, 20.00, 2.00, 3.00, 0.00, '2024-05-11 21:31:28'),
(4, 'Mathavan ', 'Salem z ', '2024-05-11', 'Ultra Tech', 'HSKBD', 2, 10.00, 2.00, 3.00, 0.00, '2024-05-11 21:35:03'),
(5, 'Mathavan ', 'Salem z ', '2024-05-11', 'Dalmia Cement', 'HSKBD', 5, 50.00, 0.00, 0.00, 250.00, '2024-05-11 22:12:54'),
(6, 'Mathavan ', 'Salem z ', '2024-05-12', 'Ultra Tech', 'HSKBD', 6, 60.00, 8.00, 2.00, 370.00, '2024-05-11 22:33:03'),
(7, 'Mathavan ', 'Salem z ', '2024-05-12', 'Ultra Tech', 'HSKBD', 6, 60.00, 8.00, 2.00, 370.00, '2024-05-11 22:33:03'),
(8, 'Mathavan ', 'Salem z ', '2024-05-12', 'Ultra Tech', 'HSKBD', 6, 60.00, 8.00, 2.00, 370.00, '2024-05-11 22:33:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
