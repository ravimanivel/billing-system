<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHITHRA AGENCY</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="icon" type="icon" href="invoice.jpg">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> 
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .container_1 {
            max-width: 900px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 0;
                box-shadow: none;
            }
        }
        nav{
        	text-align: center;

        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container_1">
            <a class="navbar-brand" href="#">Invoice System</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php" style="color:black;text-align: center;margin-right: 150px;"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="invoice.php" style="color:black;text-align: center;margin-right:150px;"><i class="fas fa-file-invoice-dollar"></i> Invoice</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales.php" style="color:black;text-align: center;margin-right: 150px;"><i class="fas fa-chart-line"></i> Sales</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <h2 class="text-center mb-4">Create Invoice</h2>
        <form action="app.php" method="post" >
            <!-- Your form fields here -->
            <div class="form-group">
                <label for="customerName">Customer Name</label>
                <input type="text" class="form-control" id="customerName" name="customerName" required>
            </div>
            <div class="form-group">
                <label for="customerAddress">Customer Address</label>
                <input type="text" class="form-control" id="customerAddress" name="customerAddress" required>
            </div>
            <div class="form-group">
                <label for="date">Date</label>
                <input type="text" class="form-control" id="invoiceDate" name="date" readonly>
            </div>
            <div class="form-group">
                <label>Cement Name</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="cementName" id="ultraTech" value="Ultra Tech" required>
                    <label class="form-check-label" for="ultraTech">Ultra Tech</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="cementName" id="dalmiaCement" value="Dalmia Cement" required>
                    <label class="form-check-label" for="dalmiaCement">Dalmia Cement</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="cementName" id="ramcoCement" value="Ramco Cement" required>
                    <label class="form-check-label" for="ramcoCement">Ramco Cement</label>
                </div>
            </div>
            <div class="form-group">
                <label for="hsnCode">HSN Code</label>
                <input type="text" class="form-control" id="hsnCode" name="hsnCode" required>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>
            <div class="form-group">
                <label for="price">Price (Per Unit)</label>
                <input type="number" class="form-control" id="price" name="price" required>
            </div>
            <div class="form-group">
                <label for="sgst">SGST (%)</label>
                <input type="number" class="form-control" id="sgst" name="sgst" required>
            </div>
            <div class="form-group">
                <label for="cgst">CGST (%)</label>
                <input type="number" class="form-control" id="cgst" name="cgst" required>
            </div>
            <div class="form-group">
                <label for="grantTotal">Grant Total</label>
                <input type="text" class="form-control" id="grantTotal" name="grantTotal" readonly>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="transactionDateTime" name="trans_D_T" value="<?php echo date('Y-m-d H:i:s'); ?>" readonly style="display: none;">
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary">Create Invoice</button>
            </div>
        </form>
    </div>
 

<script>
    // Get the current date
    var currentDate = new Date();
    
    // Format the date as YYYY-MM-DD
    var formattedDate = currentDate.getFullYear() + '-' + ('0' + (currentDate.getMonth() + 1)).slice(-2) + '-' + ('0' + currentDate.getDate()).slice(-2);
    
    // Set the value of the date input field
    document.getElementById('invoiceDate').value = formattedDate;
</script>


    <!-- Bootstrap Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
    $(document).ready(function(){
        $('#quantity, #price, #sgst, #cgst').keyup(function(){
            var quantity = parseFloat($('#quantity').val());
            var price = parseFloat($('#price').val());
            var sgst = parseFloat($('#sgst').val());
            var cgst = parseFloat($('#cgst').val());
            var grantTotal = (quantity * price) + sgst + cgst;
            $('#grantTotal').val(grantTotal.toFixed(2));
        });
    });
    </script>
</body>
</html>
